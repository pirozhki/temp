# 10. できること・できないこと・未解明

## できること(実機で確認済み)

| 項目 | 内容 | 詳細 |
|---|---|---|
| **新しいカーネル(Linux 6.12 LTS)+ Debian 12** | SPI からの単独起動、SATA・Ethernet・MTD・MCU、地デジの受信と B-CAS 復号、LED・電源ボタン・電源断と起床タイマ、USB ホスト(EHCI+OHCI)、スワップ。試験中(BS/CS は 6.12 では未確認) | [docs/22](22_new_kernel_612.md)・[docs/23](23_kernel_feature_inventory.md) |
| Debian直起動 | 自前カーネル + 内蔵initramfs で、p3 の Debian wheezy (mipsel) を `sysvinit` PID 1 として起動。ssh / cron / dhcp など通常運用 | [docs/05](05_kernel_and_direct_boot.md) |
| カーネル差し替え | SPIの KNL 領域だけを書き換え。U-Boot / 4段目ブートは無改変(A/B の B を純正のまま残して安全網にする)。**B の正体は出荷時カーネル(公式 v2.00〜v2.60 の KNL と同一)。A の KNL を壊す(CRC不一致)と B で起動することを実機で確認**(HDD経由で復旧済み) | [docs/05](05_kernel_and_direct_boot.md) |
| 自前カーネルのビルド | SIE公開のGPLソース + Docker(GCC 4.3.2)でビルド。純正ドライバ `xcode4drv.ko` もそのままロードできる | [docs/05](05_kernel_and_direct_boot.md) |
| 公式ファームの起動 | 自前カーネル上で、公式 v1.00 / v2.60 のユーザランドが起動し、WebUIまで表示される | [docs/03](03_firmware_format.md) |
| 起動失敗時の自動復帰 | 起動カウンタ(2回連続で成功印なし)または `/etc/nasne-direct-boot` の欠如で、Sony の miniroot に切り替わり、**ssh で入れる救出用の状態**になる(公式アプリは `official-once` のときだけ。実機で確認) | [docs/05](05_kernel_and_direct_boot.md) |
| HDDの紐付けの生成 | `00110022.dlm`(個体IDのマネージャ)をオフラインで生成。HDD全損機の復旧、他の本体への移植 | [docs/03](03_firmware_format.md)、[docs/04](04_hdd_recovery_guide.md) |
| ウォッチドッグ停止 | MCUへ I2C で `[0x20, 0x01]`。起動時サービスで自動化 | [docs/06](06_mcu_watchdog.md) |
| **PWR LEDの点灯** | MCUの表示コード(レジスタ `0x10`)へ `0x32` を書く(点滅 → 点灯)。起動時サービスで自動化。Webカメラで確認 | [docs/06](06_mcu_watchdog.md) |
| **前面LED(REC・LAN・PWR)** | **REC(赤)はチューナー使用中に点灯、LAN(橙)はネットワークが確立したら点灯のまま**(公式と同じ。点滅しない)。REC は SoC の GPIO ポート10 の bit `0x100`、LAN は `0x200`。`nasne-ledd`(常駐。`nasne-recpt1` のロックを `/proc/locks` で読むだけ)が、`nasne-ledctl` で切り替える。**PWR は緑のまま、状態ページが異常を報告している間だけ赤**(HDD の温度・SMART、保留/代替セクタの**急増**、ディスク使用率、チューナーの固まり、メモリ不足。`NASNE_LED_PWR_WARN=0` で無効)。HDD LED はディスクのアクセスに連動(ソフトの操作ではない)。Webカメラで確認 | [docs/06](06_mcu_watchdog.md) |
| ブートチェーンの解読 | U-Boot 1.1.3 / 4段目ブート / `.dlm` 暗号 / SPIの地図。署名検証なし | [docs/02](02_boot_chain.md)、[docs/03](03_firmware_format.md) |
| チューナーの選局 | 地デジ(UHF 13〜62)を復調IC/RFチューナーICのI2C操作で選局し、ロック・C/Nを読む。BS/CS110 は他の人の報告で受信でき、`nasne-recpt1` が `BS1`〜`BS23`・`CS2`〜`CS24` を指定できる(作者の環境では信号が無く未検証) | [docs/08](08_tuner_i2c.md) |
| **地デジの受信・復号・配信** | **B-CASカードで復号した元画質(MPEG-2 HD)のTS**を、`recpt1`互換コマンドとHTTPで取り出す。SI(番組表の元データ)も混ぜる。連続2分(約230MB)で同期エラー・スクランブル残りなし | [docs/11](11_tv_streaming.md)、[docs/12](12_ts_and_bcas_decrypt.md) |
| **v1.00なしでのHDD復旧** | 空のHDDから公式 v2.60 だけで起動。HDD登録情報 `.hai` の生成と、p3の初期構造(`p3init`)で、v1.00 を使わずに済む | [docs/04](04_hdd_recovery_guide.md)、[docs/15](15_p3_structure_and_hai.md) |
| **SPIフラッシュの読み出しバックアップ** | 書き込まず、HDDの `00550066.dlm` 差し替えだけで、nasne自身がSPIを読んでHDDに置く(原本ダンプとKNLスロット以外一致) | [docs/16](16_spi_backup_dlm.md) |
| **ビルドの通し(クリーンな環境)** | `nasne_setup.py` で、公式ファームの取得 → カーネル → KNL → Debianツリー → `.dlm` まで、最小構成の Debian 13 の仮想マシンで最後まで通った(追加パッケージは docs/13 の表のとおり)。そのVMで作った `.dlm`(embed)を実機に入れて、Debianが起動することも確認(SPIのKNLはVMで作ったものと一致、ホストのcross gccでビルドしたMIPSツールも実機で動作、地デジのスキャンも成功) | [docs/13](13_full_setup_from_official_hdd.md) |
| **SPIをバックアップへ戻す(`--mode restore`)** | バックアップから KNL / BKNL スロットだけを、違うときだけ書き戻す(消去→書き込み→読み戻し検証→再起動)。実機で、自作カーネル入りのバックアップから書き戻し・検証OK・再起動後に「一致」を確認 | [docs/16](16_spi_backup_dlm.md) |
| **本体のNVとHDDの食い違い → NVリセット** | 原本のNVと(別に初期化した)HDDの組み合わせで、公式アプリが固まるのを再現。NVを空にすると復旧(公式はNVを作り直す)。`--mode nvreset` の `.dlm`(公式のHDD用)と `nasne-nvreset`(Debian用)で実機確認。`official-once` は、NVとHDDが揃っていれば動く | [docs/16](16_spi_backup_dlm.md)、[docs/04](04_hdd_recovery_guide.md) |
| **状態ページ**(HDD温度・SMART・メモリ・ディスク・MCU・チューナー) | 実機で `/` `/status.json` `/metrics` と、SMARTの値が `smartctl` と一致することを確認。Home Assistant(コンテナ)で13個のエンティティが値を持つことも確認。VMで作った `.dlm`(状態ページ入り)を実機に新規インストールして、再起動後に状態ページ・`smartctl` が既定で動くことも確認 | [docs/18](18_status_page.md) |
| **電源オフ・予約起動(タイマ起床)** | Debianの `poweroff` で実際に電源が切れる(MCUへ `[0x02,0x01]`、待機約1W)。`WAKE_SECONDS` で、切ってから指定秒数後に自動起動(起床タイマ `[0x02,0x02,u32]`、約10.5ms/カウント。**書いた約1.6秒後に電源が切れる**)。電源ケーブルの抜き差しでも起動。**EPGStation の予約に合わせて、予約の5分前に自動で起床**(`nasne-waked`)し、**タイマ起床で使われなくなったら自動で電源オフ**(任意)。実機で、予約 → 起床 → 録画 → 自動オフを通した | [docs/06](06_mcu_watchdog.md) |
| **電源ボタン長押しでの電源オフ** | MCUのステータス2バイト目のbit4(`0x10`)がラッチされる(押下で `0x80`→`0x90`)ので、`nasne-powerbtn` が検出して `poweroff` する。実機で「長押し→数秒で電源オフ」を確認。**ラッチは `reboot` ではクリアされず、コールドブートで消える**(`reboot` をまたいで残った古いラッチは無視する) | [docs/06](06_mcu_watchdog.md) |
| B-CASの検出・活性化 | ドライバ経由で、カードの挿入検出と活性化(復号にはカードIDの取得は不要) | [docs/07](07_driver_ioctl_bcas.md) |

## できないこと

| 項目 | 理由 |
|---|---|
| 一部の録画ソフトとの連携 | Mirakurun・EPGStation・tvheadend は動作確認済み(スキャン・番組表・録画。[contrib/epgstation](../contrib/epgstation/README.md)、[contrib/tvheadend](../contrib/tvheadend/README.md))。Jellyfin はチャンネルの取り込みまで(ライブ視聴は未確認)、Kodi は未確認 |
| 同時に複数の番組・チャンネル | チューナーは1系統・1サービスずつ。2つ目のチューナーの有無や使い方は未調査 |
| BS/CSの受信 | 作者の環境にはBS/CSの信号が来ておらず(建物に配信が無いことを確認)、**作者の実機では未検証**。ほかの人の実機で、スロット(TSID)選択を足して BS全局・CS110 が受信できたとの報告をもとに `nasne-recpt1` に取り込んだ([docs/08](08_tuner_i2c.md)、[docs/11](11_tv_streaming.md)) |
| B-CASカードIDの取得 | `CARD_ID_ACQUIRE` / `BCASMSG` の応答が返らない(復号には不要) |
| RTC(ハードウェア時計) | カーネルの `vixs-rtc` は評価ボードのDS1339(I2C `0xD0`)用で、この基板には無く読めない(`unable to read the hardware clock`)。時計は1970年から始まるので、`fake-hwclock`(最後に保存した時刻から再開)+ `ntpdate`(ネットワーク起動時に補正)で対処(`prepare_tree.sh` が標準で入れる) |
| パッケージ追加(apt) | wheezy は EOL。`archive.debian.org` に向け(`[trusted=yes]` と `Check-Valid-Until false`)で使える(`prepare_tree.sh` が設定) |
| UART / JTAG | 基板に信号が配線されていない |
| 公式の録画データの利用・DLNA配信・DTCP-IP(**やらない**。DTCP-IPで保護された録画の取り出し・復号は対象外) | 純正アプリは動かさない。録画は別の録画ソフト側で行う前提。HDD登録情報 `.hai` と録画DB(`00000015/` の `.dat`)の暗号は解読済みだが、録画の表(`cont_inf_tbl`)の構造は確認済み([docs/15](15_p3_structure_and_hai.md))。録画ファイル本体の取り出し・復号は対象外(やらない)([docs/15](15_p3_structure_and_hai.md)) |
| ブートローダの差し替え | U-Boot / 4段目の差し替えは未実施(SPIの先頭1MBは難読化されており、書き込み時は難読化の適用が必要)。カーネル引数(`console=` など)は変えられない |
| Sony miniroot を使わない完全Debian化 | SPIのRFS(Sony miniroot)はまだ読み込まれる(`switch_root` で捨てられるだけ)。自前RFSは未作成 |

## 未解明・未検証

| 項目 | 状況 |
|---|---|
| ファーム(メディアエンジン)が起動後しばらくして `FW_HANGUP` になる | 原因不明。`rc.xcode4` の再読込で復活する(`nasne-recpt1` は開始時に確認して自動で再読込する)。I2Cのみ使う用途には影響しない |
| **複数クライアントの頻繁な開閉で、`nasne-recpt1` が D 状態のまま固まる(まれに)** | tvheadend の常時スキャンと Jellyfin のプローブを同時に動かして再現(数十〜数百回に1回)。ドライバの中で戻らず、電源の入れ直しまで復旧しない。待機(10秒)の有無に関係なく起きた。**状態ページが検知して警告する**。常用はクライアントを1つに絞る |
| 復号ストリームを開いたまま強制終了するとnasneが固まることがある | 原因不明(pingは通りsshは応答せず、電源の抜き差しで復旧)。通常の終了(SIGTERM・接続切断)では起きない |
| ワンセグのサービスに復号ストリームを開くと、ドライバ内で戻らなくなる | **再現して特定**: ワンセグ(PMT PID 0x1FC8)に対して `OPEN_SECUREDTS` を開くと、`RECV` ioctl がD状態のまま戻らない(`SIGKILL`も効かない)。他のサービスは影響なし。nasne全体は応答し、`reboot -f` で復旧する。`nasne-recpt1` はワンセグを一覧に載せず、明示指定も404で拒否する。ファーム側の仕様かバグかは未解明 |
| 公式ファームで地デジのスキャンが動かない(開発機) | 公式のクリーンな構成(自作カーネル・観測用の `LD_PRELOAD`・telnet なし、SPIは原本)では **スキャンできた**。開発中に動かなかったのは、公式に自作カーネルや観測用シムを混ぜた状態で試していたためとみられる(原因の細部は未確認) |
| 公式 `procmng` が止まる条件(PWR/REC赤点灯、LAN点灯、ping・ARPとも無応答) | procmng は検査に通らないと `/sbin/halt` を呼んで止まる(マネージャが不完全、`/dev/mtd0` が無い等で再現)。p3(録画領域)の初期構造(`.hai`、録画DBの雛形)が無いと、起動の約35秒後に本体が固まる(ネットワークも切れる。[docs/15](15_p3_structure_and_hai.md))。別件として、Debian直起動の機体から公式アプリを起動して固まる例は、p3の初期構造不足が原因の可能性が高い(`p3init` 後の再試験は未実施)。どの検査が決め手かは未特定。電源の入れ直しで戻る |
| MCUのステータス6バイト(末尾2バイトは「最後のコマンドからの経過(10ms単位)」、2バイト目の0x80はウォッチドッグ停止中・bit1はタイマ起床・bit4は電源ボタン長押しのラッチ)、電源・タイマ系コマンド | 一部判明。`[0x02,0x01]`=電源断、`[0x02,0x02,u32]`=起床タイマを設定して(約1.6秒後に)電源断、`[0x04,0x02]`=再起動要求。そのほか(`[0x04,0x01]` など)は未解読 |
| `/dev/mem` でI2Cレジスタを直接叩くとブロック0がNACKになる理由 | 未解明(HWミューテックスの絡みと推測)。**直接叩くとMCUのI2Cが固まる** |
| 右上の16ピンIC(`L4AA / P217`)の正体、BS の LNB 給電の制御箇所 | 未確定(給電回路かもしれない、という推測だけ)。復調IC(東芝 TC90532XBG)・RFチューナー(MxL301=地デジ、STV6110A=BS/CS)は基板の目視で確定済み([docs/01](01_hardware.md)) |
| バス0 `0x2a` のデバイス | 未確定(何を読んでも `00`) |

| SPI先頭1MBの残り | **ECC領域は解読済み**(U-Boot等のHamming(72,64)パリティ、[docs/02](02_boot_chain.md))。`0x0`ブロックは、ヘッダ(`55 aa` の目印)と、SoC ROM向けのNANDフラッシュ素子の一覧表(Hynix・Samsung・Micron・Spansion・Numonyx・Toshiba の型番。SDK共通で、SPI起動のnasneでは使われないとみられる)。`0x4000`〜`0x7bff` の乱数様15KBと、`0x90000`/`0xA0000` の各3328バイトのblob(互いに無関係、既知のBlowfish・XORパッドでは復号できない)は**未解読** |

## 作者側では検証不可(別の本体が必要なもの)

作者は CECH-ZNR2J を **1台しか持っていない**ため、次の項目は作者側では検証できません。別の本体をお持ちの方の確認結果(issue等)を歓迎します。

| 項目 | 内容 |
|---|---|
| 別の個体での動作全般 | HDD復旧手順(`phase1`→`read-id`→`final`→`p3init`)、`.hai` の生成、`00110022.dlm` の生成が、別の個体でも同じ結果になるか |
| 録画DBの雛形が個体IDに依存しないか | 解読の結果、直下の2ファイルの中身は世代カウンタだけで、個体IDを含まない([docs/15](15_p3_structure_and_hai.md))。この項目は解消 |
| 別のモデル(CECH-ZNR1J など) | 基板・チューナー構成・SPI配置が同じか |
| v2.60より古いファームがSPIに入っている本体 | 作者の本体は、KNLを v1.51 世代に戻した状態までは試した(公式アプリは起動)。出荷時から古い本体のSPI全体(RFS・BRFS の版が違うかなど)は不明 |
| 古い公式ファーム(v1.52〜v2.5x)の途中の状態 | 公式の更新は一度で v2.60 まで上がるので止められない(静的な解析では、v2.00 以降は SPI が同一)。HDD側に旧版の `.dlm` を置く方法でなら試せる |
| 別の個体のHDDを付け替えたときの挙動 | `ChipID ERROR` で止まる負の対照(別IDのマネージャで確かに止まるか)、別本体への移植 |
| 個体差のあるハードウェア挙動 | チューナーの感度、`FW_HANGUP`、強制終了時の固まりなどが他の個体でも出るか |

## 作者側で検証済み・残っているもの

HDDは複数あるため、次は作者側で確認しました(2026-10、実機1台)。

- ✅ HDDの容量・メーカー違い(320GB・500GB・1TB)での復旧手順と直起動
- ✅ `phase1` から始めて `p3init` で完成させる最初から続けた通し
- ✅ SPIバックアップ `.dlm` の `--dest p3`、Debian直起動HDDでの動作
- ✅ Debian直起動の機体から公式アプリを一度だけ起動する試験(`official-once`)
- ✅ 直起動の失敗時フォールバック(起動カウンタ `xx` → Sony の miniroot + ssh の救出状態)、**SPI の A/B フォールバック**(KNL の CRC 不一致で BKNL が起動)
- ✅ 長時間運用(約4日、予約録画12本)、tvheadend 連携、EPGStation の数日の連続運用
- 残り: BS/CS の試験(BSが来ている入力での再試験)、2つ目のチューナーの調査、KNL がほぼ消去されたときのフォールバック(未検証。B で起動しなければ CH341A での書き戻しが要る)

## 動作確認した範囲

検証は CECH-ZNR2J の1台で、HDDは320GB・500GB・1TB を使った。ファームは v1.00 / v1.51 / v2.60(ほかの版は構造の解析のみ)。
他のモデル(CECH-ZNR1J など)や他のファーム版数での動作は未確認です。結果をissueで共有してもらえると助かります。
