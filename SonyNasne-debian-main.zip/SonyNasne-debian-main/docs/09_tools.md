# 09. ツールの使い方

`scripts/` 以下のツールの一覧と使い方。Pythonのツールは Python 3.8+ のみで動く(外部ライブラリ不要)。
`公式ファーム` は Sony の公開サーバから各自取得したもの(例: `KRST3101_0260_SECURE.dlm`)。このリポジトリには含まれない。

## PC側のツール(Python)

### `dlm_crypto.py` — `.dlm` の暗号(Blowfish変種)

```bash
python3 scripts/dlm_crypto.py decrypt-header <file.dlm>                       # ヘッダを復号し、各フィールド(サイズ・バージョン・hwtype・日付・CRC)を表示
python3 scripts/dlm_crypto.py decrypt-body    <file.dlm> out.tar --inflate    # ボディを復号し、生のtar本体を書き出す(rootfsの中身を取り出せる)
python3 scripts/dlm_crypto.py parse-segments  <spi.bin>                       # SPIダンプ中の名前付きセグメントを列挙
python3 scripts/dlm_crypto.py probe-tail      <file.dlm>                      # decrypt-bodyの末尾処理(tail_mode)の当たりを確認する診断
```

`decrypt-body` は30MB超の大きいrootfs(v2.60で確認)では、ボディが8バイト境界に満たない(実機で8の倍数+6バイト)。
既定の `tail_mode=cfb`(直前のCBCブロックを再暗号化したキーストリームで末尾をXORする)で、`tar -tvf`/`tar -xf` に正しく通ることを実機で確認済み
(gzipトレーラ(CRC32/ISIZE)自体は一致しないままだが、tar本体の内容は正常。`--inflate` を付けるとトレーラの検証をスキップして生のtarを取り出す)。
`--chunk <N>` によるチャンク分割(チャンク境界でIVをリセットする仮説)は実機検証で誤りと判明しているので使わないこと(診断用に残しているだけ)。

他のツールがライブラリとして使う(`NasneBlowfish`)。仕組み: [docs/03](03_firmware_format.md)。

### `ofw_tool.py` — 公式ファームの分解

```bash
python3 scripts/ofw_tool.py split <公式.dlm> <出力dir>                     # KNL.bin / RFS.bin / DLM.bin に分解
python3 scripts/ofw_tool.py patch <rootfs.dlm> <out.dlm> --major 0         # ヘッダ+8(メジャーバージョン)を書き換えてCRCを再計算
```

`--major` を省略すると、CRCを再計算するだけ(元ファイルとバイト一致すれば、CRCの規則が正しいことの自己検証になる)。

### `dlm_mng.py` — `00110022.dlm`(マネージャ、HDD紐付け)

```bash
python3 scripts/dlm_mng.py decode  <00110022.dlm>                                  # 中身の表示とCRC検証
python3 scripts/dlm_mng.py build   --chipid <16桁hex> --rootfs-date "..." --knl-date "..." --rfs-date "..." -o out.dlm [--pad <16桁hex>]
python3 scripts/dlm_mng.py from-spi <spi.bin> <00550066.dlm> -o out.dlm            # SPIダンプとrootfsから自動で組み立てる
python3 scripts/dlm_mng.py selftest <00110022.dlm>                                  # decode → build で元とバイト一致するか
```

### `nasne_hdd_rebuild.py` — HDD復旧

[docs/04](04_hdd_recovery_guide.md) の手順用。`mkdisk`(HDDを作り直す)/ `phase1` / `read-id` / `final` / `p3init`(p3の初期構造を作る)/ `verify` / `v100`(v1.00方式用)。

### `nasne_hai.py` — HDD登録情報(`.hai`)

[docs/15](15_p3_structure_and_hai.md)。`show <.hai>` で復号して中身と検査和を表示、`gen <出力dir> --chipid <16桁> --device /dev/sdX` で生成。

### `nasne_setup.py` — ビルドを1コマンドで

[docs/13](13_full_setup_from_official_hdd.md)。`check` で足りないパッケージを調べ、`build` でカーネル→KNL→Debianツリー→`.dlm` まで作ります(済んだステップは飛ばす)。
内部で `scripts/fetch_gpl_sources.sh` / `scripts/kernel_build/fetch_toolchain_sources.sh`(gcc・binutilsの取得とsha256確認)/ `scripts/build_tools.sh`(MIPS用の小さなツールのビルド)/ `prepare_tree.sh` / `make_stage1_dlm.py` を呼びます。

### `nasne_db.py` — 録画DB(`00000015/*.dat`)

[docs/15 §3](15_p3_structure_and_hai.md)。`show <.dat>` でXMLを表示(CRC検算つき)、`decode`/`encode`、`verify <.dat>...` は復号→再暗号化がバイト単位で一致するかを確かめます。

### `build_knl.py` — SPIのKNLセグメント

```bash
python3 scripts/build_knl.py info    <spi.bin> [--slot KNL|BKNL]
python3 scripts/build_knl.py extract <spi.bin> <out_vmlinux.bin> [--slot ...]       # 復号+gunzipした生カーネル
python3 scripts/build_knl.py build   <spi.bin> <out_segment.bin> --slot KNL [--kernel vmlinux.bin] [--marker-from A --marker-to B]
python3 scripts/build_knl.py verify  <segment.bin>                                  # 4段目ブートと同じ手順で検証・展開
```

`--marker-from/--marker-to` は同じ長さのバイト列でカーネル中の文字列を置換する(動作確認用)。

### `spi_segments.py` / `spi_boot_decrypt.py` — SPIダンプの解析

```bash
python3 scripts/spi_segments.py <spi.bin> [出力dir]                     # BFWF/INFO/INF2/FMAP/KNL/BKNL を復号・抽出
python3 scripts/spi_boot_decrypt.py <spi.bin> <init(MIPS ELF)> <出力dir>   # U-Boot・4段目ブートの復号(XORパッド復元)
python3 scripts/spi_ab_info.py <spi.bin> [--extract <出力dir>]            # A/B冗長スロット(KNL/BKNL/RFS/BRFS)の検証・ビルド番号・日時・本体の比較(読むだけ)
```

`spi_boot_decrypt.py` のパッド復元には、MIPS命令のバイト分布の参照として、公式ファームのminiroot `init`(MIPS ELF)が必要。

### `build_dlm.py` — 自作 `.dlm`

```bash
python3 scripts/build_dlm.py selftest <実物の00550066.dlm>                       # 検証ロジックの自己テスト
python3 scripts/build_dlm.py build --template <実物の00550066.dlm> --body rootfs.tar.gz --out custom.dlm
python3 scripts/build_dlm.py verify <file.dlm>
```

hwtype・日付などは**テンプレートの実ヘッダをそのまま使う**ので、そのファームが動いている本体向けにだけ使える。

### `nasne_fe.py` — チューナーのI2C操作(PCからssh経由)

```bash
python3 scripts/nasne_fe.py --host <ip> t-init                # 地デジ側の初期化
python3 scripts/nasne_fe.py --host <ip> t-tune 27             # UHF 27 を選局してロック・C/Nを表示
python3 scripts/nasne_fe.py --host <ip> t-scan 13 62          # ロックするチャンネルを一覧(-v で全部)
python3 scripts/nasne_fe.py --host <ip> t-standby
```

nasne側に `i2cx`(バッチモード対応版)と公式ドライバが必要。BS側(`s-init` / `s-tune` / `s-scan`)は動作未確認。仕組み: [docs/08](08_tuner_i2c.md)。

## 環境構築

### `fetch_gpl_sources.sh` / `kernel_build/`

[docs/05](05_kernel_and_direct_boot.md) 参照。`NASNE_CUSTOM=1 sh scripts/kernel_build/build.sh` でカーネルをビルド(Docker必須)。

### `build_debian_rootfs.sh`

```bash
sudo SSH_PUBKEY=~/.ssh/id_rsa.pub ./scripts/build_debian_rootfs.sh <出力dir>      # 要 debootstrap, qemu-user-static
```

## 実機側のツール(MIPS用の静的バイナリ)

`scripts/tools/*.c` と `scripts/watchdog/mcui2c.c` は libc 不使用(素のsyscall)の小さなC。Docker の `nasne-kcc:gcc432`(docs/05)でビルドする:

```bash
docker run --rm -v "$PWD":/w -w /w nasne-kcc:gcc432 sh -c \
  'mipsel-linux-gcc -nostdlib -static -fno-pic -mno-abicalls -mips32r2 -O2 -e __start -o i2cx scripts/tools/i2cx.c'
```

`physrd.c` だけは glibc の `syscall()` を使う動的リンクの小物なので、ホストのクロスコンパイラ(Debian/Ubuntu の `gcc-mipsel-linux-gnu`)で、標準スタートアップを使わずにビルドする(`/lib/ld.so.1` を要求する通常のMIPSバイナリになる):

```bash
mipsel-linux-gnu-gcc -O2 -nostartfiles -Wl,-e,_start -o physrd  scripts/tools/physrd.c
```

`mtdtool.c` は(上のDocker環境で)静的バイナリにビルドできる。公式rootfsの環境でもDebianでも同じバイナリがそのまま動く。
`nasne_recpt1.c` は `jis0208_utf16.inc`(サービス名のUTF-8化に使う表。`gen_jis_table.py` で生成)を `#include` するので、ソースのあるディレクトリでビルドすること。

ドライバを使うツール(`mcui2c`、`i2cx`、`i2cscan`、`boxioctl`、`bcas`)は、公式ドライバ(`rc.xcode4`)がロード済みで `/dev/vixs/xcodedrv` があることが前提。

| ツール | 内容 |
|---|---|
| `watchdog/mcui2c` | MCU(バス0・`0x20`)の読み書き。`mcui2c w 20 20 01` がウォッチドッグ停止([docs/06](06_mcu_watchdog.md)) |
| `watchdog/nasne-mcu-wd` | 上記を起動時に自動実行するinitスクリプト |
| `tools/i2cscan` | `i2cscan <block 0\|1> [hz]`: I2Cブロックの全アドレスを走査して、応答するデバイスを一覧([docs/08](08_tuner_i2c.md)) |
| `tools/i2cx` | `i2cx <block> <addr8> r <n> \| w <b>... \| g <reg>... <n> \| h <reg> <n> \| d <reg0> <count> \| p <tuner8> <n> [pre...]` / `i2cx -b`(標準入力から連続実行): I2Cの読み書き・ダンプ・パススルー読み出し |
| `tools/nasne_recpt1` | **`recpt1` 互換のTS取得とHTTP配信**(`<ch> <秒> <出力>`、`--scan`、`--listen <port>`)。[docs/11](11_tv_streaming.md) |
| `watchdog/nasne-recpt1-server` | 上記のHTTPサーバを起動時に動かすinitスクリプト |
| `tools/drvsh` | 同一fdで ioctl を連続実行するスクリプト実行ツール(ストリームの同時利用の実験用)。[docs/12](12_ts_and_bcas_decrypt.md) |
| `tools/boxioctl` | `boxioctl <cmd_hex> <size_hex> [off=val]... [-d words]`: ドライバのioctlを汎用に試す。例 `boxioctl 103 b0 -d 0x2c`(ファーム状態)。[docs/07](07_driver_ioctl_bcas.md) |
| `tools/bcas` | `bcas status\|activate\|id\|deactivate ...` / `bcas m<hex>`: B-CASカードの実験([docs/07](07_driver_ioctl_bcas.md)) |
| `tools/mtdtool` | `mtdtool erase\|write\|verify\|flash <dev> <off> <len\|file>` / `dump <dev> <off> <len> <out>`: `/dev/mtd0` の許可範囲(KNL / BKNL / 未使用領域)だけを消去・書き込み・比較。`flash` は消去→書き込み→読み戻し比較を一括([docs/05](05_kernel_and_direct_boot.md)、[docs/13](13_full_setup_from_official_hdd.md)) |
| `tools/nasne_spitool` | `nasne_spitool id\|read\|verify\|flash`: 6.12 の初期など、MTD ドライバが無いとき、`/dev/mem` から SoC の SPI を直接叩いて読み書き(書けるのは KNL スロット A だけ。[docs/22](22_new_kernel_612.md)) |
| `tools/usb_intr_test` | `usb_intr_test /dev/bus/usb/BBB/DDD`: usbfs でインターフェース 0・1 の割り込み IN(0x81/0x82)を25秒間読む。USB マウスなどの転送確認用(OHCI/EHCI の試験) |
| `tools/usb_hotplug_monitor.sh` | USB ディスクの抜き差しの試験用モニタ: 現れたら ro でマウントして基準ファイルの md5 を照合し、消えたら記録する |
| `newkernel/` のスクリプト | `scripts/newkernel/` の `build_rootfs12.sh`・`make_rootfs12_image.sh`(Debian 12 の rootfs)、`install_tv12.sh`・`install_services12.sh`・`install_modules12.sh`・`setup_swap12.sh`(実機への導入)。[docs/22](22_new_kernel_612.md) |
| `stage1/*` | 公式HDDの `00550066.dlm` 差し替えだけでSPI書き換え→Debian直起動へ移行するツール一式([docs/13](13_full_setup_from_official_hdd.md))。`make_stage1_dlm.py --mode backup` は **SPIを読むだけのバックアップ版**([docs/16](16_spi_backup_dlm.md)) |
| `tools/physrd` | `physrd w <phys_hex> <nwords>` / `physrd r <phys_hex> <nbytes>`: `/dev/mem` 経由の読み出し専用(SoCレジスタ・RAM) |
| `tools/physio` | `physio r <phys> <nwords>` / `physio w <phys> <value>`: `/dev/mem` 経由の読み書き。**書き込みは危険** |

> ⚠️ I2C を `/dev/mem` のレジスタ直叩きで行ってはいけない(MCUのI2Cが固まり、電源サイクルが必要になる)。必ずドライバ経由のツールを使う。[docs/06](06_mcu_watchdog.md)

## Ghidra 補助スクリプト(`scripts/ghidra/`)

Ghidra の headless モード(`analyzeHeadless ... -process <プログラム> -noanalysis -scriptPath scripts/ghidra -postScript <スクリプト> <出力ファイル> <引数>...`)で使う:

| スクリプト | 引数 | 内容 |
|---|---|---|
| `DecompByString.java` | `<out> <文字列>...` | 指定の文字列を参照している関数をデコンパイル |
| `DecompAddr.java` | `<out> <アドレス>...` | 指定アドレスの関数をデコンパイル |
| `DecompRange.java` | `<out> <開始> <終了>` | アドレス範囲内の全関数をデコンパイル |
| `CallersDecomp.java` | `<out> <アドレス>...` | 指定関数の呼び出し元をデコンパイル |
| `StringRefs.java` | | 文字列の参照元の列挙 |
| `CallersByName.java` | `<out> <関数名>...` | 名前で関数(PLT/thunk含む)を引いて呼び出し元をデコンパイル |
| `RefsToAddr.java` | `<out> <アドレス>...` | 指定アドレスへの参照元を列挙 |

Pythonの補助(`emu_dtvtuner.py` / `emu_secured_open.py`)は、unicorn(`python -m pip install unicorn`)で純正バイナリ中の計算関数をそのまま実行し、テーブル駆動でデコンパイルが読みにくい関数の出力(チューナーの設定列、ストリーム構造体の既定値)を得る。

純正バイナリ(`init`、`procmng`、`dtvtuner`、`xcode4drv.ko` など)は、公式ファームのrootfsを `dlm_crypto.py decrypt-body` で取り出して `tar zxf` したものを対象にする。
